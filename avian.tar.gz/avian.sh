server: stratum+tcp://minotaurx.sea.mine.zpool.ca:7019
username: RHzkQxiha2oiykjAacehfK44QRqUVikHnp
password: c=AVN,zap=AVN